from math import *
from hmm import *
class HidenMarkov:

    #A 
    statesSet = {'S1', 'S2', 'S3'}
    
    """
    NOTE:  The probability numbers indicated below are in log2 form.  That is,
    the probability number =  2^number so for example 2^-1 = 0.5,  and 
    2^-2 = 0.25 ... etc.   The reason for this is that Log2 is used to represent
    probabilities so that underflow or overflow is not encounrered.  
    
    If you wish to change the probabilities in the tables below, than simple calculate 
    Log2(probability that you want/need).  For example Log2(0.33) = -0.6252,  and 
    Log2(0.5) = -1,  and so forth. 
    """
    
    #pi:
    start_probability = {'S1': -2, 'S2': -1, 'S3': -2}
    #tau:
    trans_probability = {'S1': {'S1': -1,  'S2': -1.321928,     'S3': -3.321928},
                         'S2'  : {'S1': -float('Inf'),  'S2': -1.,     'S3': -1.},
                         'S3': {'S1': -1.736966,  'S2': -2.321928,     'S3': -1.}}
    #e:
    emit_propability = {'S1': {'A': -1.321928,    'C': -1.736966,  'T': -2.321928,  'G': -3.321928},
                        'S2': {'A': -2.,   'C': -2., 'T': -2., 'G': -2.},
                        'S3': {'A': -3.321928,    'C': -2.321928,  'T': -1.736966,  'G': -1.321928}}

    def __init__(self, input_seq):
        self.input_seq = input_seq
    
    def print_dptable(self,V):
        print ("    ")
        for i in range(len(V)): 
            print ("%7s" % i)
        print

        for y in V[0].keys():
            print ("%.5s: " % y)
            for t in range(len(V)):
                print ("%.7s" % ("%f" % V[t][y]))
            print

    def viterbi(self,obs, states, start_p, trans_p, emit_p):
        V = [{}]
        path = {}

        for x in states:
            V[0][x] = start_p[x]*emit_p[x][obs[0]]  # Initializing the base cases for y==0
            path[x] = [x]
        for y in range(1, len(obs)):  # Viterbi runs for y > 0
            V.append({})
            anotherPath = {}
            for x in states:
                (prob, state) = max([(V[y - 1][x0] * trans_p[x0][x] * emit_p[x][obs[y]], x0) for x0 in states])
                V[y][x] = prob
                anotherPath[x] = path[state] + [x]
            path = anotherPath  # creating another path

        HidenMarkov.print_dptable(V)
        (prob, state) = max([(V[len(obs) - 1][x], x) for x in states])
        return (prob, path[state])

if __name__ == '__main__':
    input_seq = None
    with open("hmm_input_seq.txt") as f:
        input_seq = f.readline().strip()
        print()
        print("HMM input sequence: ", input_seq)
        hm = HidenMarkov(input_seq)
        hm.viterbi(input_seq, hm.statesSet,hm.start_probability,hm.trans_probability,hm.emit_propability)
